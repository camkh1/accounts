<?php
 namespace App\library {
	class Html_dom {
	    public function html_dom() {
	        require_once('simple_html_dom.php');
	    }
	}
}