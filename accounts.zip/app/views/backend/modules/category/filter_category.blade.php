
@foreach($categoryList as $row)
{{$row}}
@endforeach