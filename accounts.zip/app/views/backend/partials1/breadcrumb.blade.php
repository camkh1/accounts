<div class="row ">
    <div class="col-md-6 col-sm-6 col-xs-6">
           @yield('breadcrumb')
    </div>
</div>