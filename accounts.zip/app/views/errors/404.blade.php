<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0033)http://khmertalking.com/?Itemid=2 -->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>404 - Error: 404</title>
		{{HTML::style("404/error.css")}}
		{{HTML::style("404/css")}}
	<!-- //CUSTOM THEMES -->
	</head>
	<body>
		<div class="error">
			<div id="outline">
			<div id="errorboxoutline">
				<div id="error-code">404</div>
				<div id="error-message">Component not found</div>
				<a id="back-home" href="{{URL::to('/')}}" title="Go to the Home Page">Home Page</a>
				<span id="text-tip">&nbsp;</span>
			</div>
			</div>
		</div>
	</body>
</html>