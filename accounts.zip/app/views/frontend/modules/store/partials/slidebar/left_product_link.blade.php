<div class="panel-group category-products" id="accordian">
	<label class="btn-default get popular-links">
		Manage Product
	</label>
	<!--category-products-->
	<div class="panel panel-default popular-links">
		<div class="panel-heading">
			<h4 class="panel-title">
				<a
					data-toggle="collapse"
					data-parent="#accordian"
					href="#"
				>
					All My Products

				</a>
			</h4>
		</div>
		<div class="panel-heading">
			<h4 class="panel-title">
				<a
					data-toggle="collapse"
					data-parent="#accordian"
					href="#"
				>
				Reservation Products
				</a>
			</h4>
		</div>
		<div class="panel-heading">
			<h4 class="panel-title">
				<a
					data-toggle="collapse"
					data-parent="#accordian"
					href="#"
				>
				Unpublic Products
				</a>
			</h4>
		</div>
		<div class="panel-heading">
			<h4 class="panel-title">
				<a
					data-toggle="collapse"
					data-parent="#accordian"
					href="#"
				>
				Product License
				</a>
			</h4>
		</div>
	</div>
</div>