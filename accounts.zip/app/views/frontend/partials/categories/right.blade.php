<!-- ========Right side========= -->
<div class="right-sidebar">
	<!-- type:homepage, position: right meduim, limit -->
	{{ App::make('FePageController')->getFeAds(2, 5, 3) }}
	<!--=========Register seller============ -->
</div>
