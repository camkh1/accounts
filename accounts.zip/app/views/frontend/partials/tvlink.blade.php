<div class="visible-lg portfolio-item-holder">
		<div class="col-lg-2">
			<div
				class="tile-bt solid-darkblue shadow-blue mt-tab mt-loadcontent"
				id="metrotab">
				<a
					href="http://www.merltv.com/2014/10/hang-meas-hdtv-khmer-live-tv-online-tv-cambodia.html"
					target="_blank"> <img alt=""
					src="http://3.bp.blogspot.com/-qMEtjwyfRXc/VaV1-gQgAQI/AAAAAAAAKec/lV9fNFKUWCM/s100/rhm-logo%2B%25281%2529.png"
					style="width: 60px; height: auto;"> <span class="light-text">HM TV</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div
				class="tile-bt solid-darkblue shadow-blue mt-tab mt-loadcontent"
				id="metrotab">
				<a
					href="http://www.merltv.com/2011/08/tvk-channel-khmer-live-tv-online.html"
					target="_blank"> <img alt=""
					src="http://www.khmermovies.co/uploads/tv/tvk_logo.png"
					style="width: 60px; height: auto;"> <span class="light-text">TVK
						TV</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div
				class="tile-bt solid-darkgreen shadow-green mt-tab mt-loadcontent"
				id="metrotab">
				<a
					href="http://www.merltv.com/2013/04/live-bayon-news-channel-for-online.html"
					target="_blank"> <img alt=""
					src="http://www.khmermovies.co/uploads/tv/bayontv.png"
					style="width: 60px; height: auto"> <span class="light-text">Bayon
						TV</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div
				class="tile-bt solid-darkgreen shadow-green mt-tab mt-loadcontent"
				id="metrotab">
				<a
					href="http://www.merltv.com/2013/04/live-bayon-news-channel-for-online.html"
					target="_blank"> <img alt=""
					src="http://www.khmermovies.co/uploads/tv/bayontv.png"
					style="width: 60px; height: auto"> <span class="light-text">Bayon
						TV News</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div
				class="tile-bt solid-violetred shadow-red mt-tab mt-loadcontent"
				id="metrotab">
				<a href="http://www.merltv.com/2013/04/live-sea-tv-online-channel-khmer-live-kh.html"
					target="_blank"> <img alt=""
					src="http://www.khmermovies.co/uploads/tv/logo_seatv.png"
					style="width: 60px; height: auto;"> <span class="light-text">Seatv
						TV</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div
				class="tile-bt solid-orange-2 shadow-orange mt-tab mt-loadcontent"
				id="metrotab">
				<a
					href="http://www.merltv.com/2013/04/live-tv5-online-5-channel-khmer-live-tv.html"
					target="_blank"> <img alt=""
					src="http://www.khmermovies.co/uploads/tv/logo_tv5.png"
					style="width: 50px; height: auto;"> <span class="light-text">TV5
						TV</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div class="tile-bt solid-blue-2 shadow-blue mt-tab mt-loadcontent"
				id="metrotab">
				<a
					href="http://www.merltv.com/2012/02/khmer-live-tv-online-tv3-channel.html"
					target="_blank"> <img alt=""
					src="http://www.khmermovies.co/uploads/tv/logo_tv3.png"
					style="width: 50px; height: auto;"> <span class="light-text">TV3
						TV</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div class="tile-bt solid-red-2 shadow-red mt-tab mt-loadcontent"
				id="metrotab">
				<a
					href="http://www.merltv.com/2011/08/watch-tv-9-live-tv-from-cambodia.html"
					target="_blank"> <img alt=""
					src="http://www.khmermovies.co/uploads/tv/logo_ctv9.png"
					style="width: 50px; height: auto;"> <span class="light-text">TV9
						TV</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div
				class="tile-bt solid-darkblue shadow-blue mt-tab mt-loadcontent"
				id="metrotab">
				<a
					href="http://www.merltv.com/2013/04/live-apsara-tv-online-tv-channel-11.html"
					target="_blank"> <img alt=""
					src="http://www.khmermovies.co/uploads/tv/logo_apsaratv.png"
					style="width: 50px; height: auto;"> <span class="light-text">Apsara
						TV</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div
				class="tile-bt solid-green-2 shadow-green mt-tab mt-loadcontent"
				id="metrotab">
				<a href="http://www.merltv.com/2011/08/radio-free-asia-khmer.html"
					target="_blank"> <img alt=""
					src="https://pbs.twimg.com/profile_images/524525524362596352/HizkT3hV_400x400.png"
					style="width: 50px; height: auto;"> <span class="light-text">RFA
						Radio</span>
				</a>
			</div>
		</div>
		<div class="col-lg-2">
			<div
				class="tile-bt solid-orange shadow-orange mt-tab mt-loadcontent"
				id="metrotab">
				<a
					href="http://www.merltv.com/2011/08/khmer-post-media-center-cambodian.html"
					target="_blank"> <img alt=""
					src="https://lh3.googleusercontent.com/-me02oFnOyUU/Vbedd276LUI/AAAAAAAADWE/WL-pMnueNNA/s180-Ic42/The%252520Khmer%252520Post%252520Radio_180.png"
					style="width: 50px; height: auto;"> <span class="light-text">Khmer
						Post Radio</span>
				</a>
			</div>
		</div>
			<div class="col-lg-2">
			<div class="tile-bt solid-red shadow-red mt-tab mt-loadcontent"
				id="metrotab">
				<a href="http://www.merltv.com/2011/08/test_07.html"
					target="_blank"> <img alt=""
					src="http://i.ytimg.com/vi/sOwmZl0JjQ4/1.jpg"
					style="width: 50px; height: auto;"> <span class="light-text">VOA
						Radio</span>
				</a>
			</div>
		</div>
		<div class="clear"></div>
	</div>