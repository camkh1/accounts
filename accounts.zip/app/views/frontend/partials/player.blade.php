<div class='queue-closed' id='player-wrapper'>
<div id='player-container'>
  <div class='player'>
    <div class='img-container'>
      <img class='img' 
      height='60' 
      id='now-playing-image' 
      src='http://2.bp.blogspot.com/-dNiBWnr-4rM/VZmXP0_O5LI/AAAAAAAAKac/RPRdzjRTUCo/s1600/default-album-175x175.jpg' 
      title='Just give me a reason' width='60'/>
    </div>
    <div class='' id='now-playing'>
		<div class='transparent_img' 
		style='clip: rect(0px 1518px 596px 0px); background: url(http://2.bp.blogspot.com/-Quu1CHWjVUU/VZ5Hluw-D-I/AAAAAAAABhY/qUARflfxRys/s72-c/007.JPG) 0px 0px / cover no-repeat scroll rgba(0, 0, 0, 0);z-index: 300;'>
		</div>
      <div class='inner'>
        <!-- player_activity -->
        <div class='player_activity'>
          <span class='song-current-like fblike'> </span>
            <a class='video_player grd-green hidden-xs' data-type='playvideo' data-value='playfromplayer' href='javascript:void(0)' id='video_player_link' style='display: none;' title='Watch video'><i class='fa fa-play'></i> Video</a>
            <a class='favorite hidden-xs' data-type='favp' href='javascript:void(0)' id='favorite' title='Add to favorites'><i class='fa fa-heart'></i> Favorite</a>
            <a class='pshare' data-type='sharep' href='javascript:void(0)' id='forward' title='Share'><i class='fa fa-share'></i> Share</a>
            <a class='hidden-xs' data-type='addtopp' href='javascript:void(0)' id='createnew' title='Add To Playlist'><i class='fa fa-plus'></i> Add to Playlist</a>
        </div>
        <!-- end player_activity -->

        <div class='metadata' id='now-playing-metadata' style='display: block;'>
          <a class='now-playing-link song-link song show-song-tooltip no-title-tooltip' data-song-id='38129312' data-tooltip-cache-key='playerSong' title='Just give me a reason'>
            Just give me a reason
          </a>
          <span data-translate-text='BY'>
            by 
          </span>
          <a class='now-playing-link artist' href='#!/artist/Pink/127' title='Pink'>
            Pink
          </a>
          <span data-translate-text='ON'>
            on 
          </span>
          <a class='now-playing-link album' href='#!/album/The+Truth+About+Love/8052484' title='The Truth About Love'>
            The Truth About &#8230;
          </a>
        </div>
      </div>
    </div>
    <div class='shuffle' id='shuffle'></div>
    <!-- Volume --> 
    <div class='volume-control'>
      <span class='tooltip'></span>
      <div class='volume-slider'>
      </div>
      <div class='overlay'>
        <div class='icon'></div>
      </div>
    </div>
    <!-- end Volume --> 
    <div class='spectrum'>
      <img border='0' id='spectrump' src='http://2.bp.blogspot.com/-QPdeZUJ469A/UX1H5tdV7zI/AAAAAAAAA6Q/8hmjBsdqj2w/s000/spectrum-puase.gif' style='display:block'/>
      <img border='0' id='spectrum' src='http://4.bp.blogspot.com/-69lpD8NFQyA/UXbcDHMVBmI/AAAAAAAAA3Q/RsFibD-Wi0U/s1600/spectrum.gif' style='display:none'/>
    </div>
    <audio id='on-play-song' preload='none' src='http://music.khmer.be/Data/mp3/585/bbccd4a7-d2a0-42d6-aab2-d99e371e5778.mp3'></audio>
  </div>
</div>
</div>