  <!--play-list sidebar-->
  <div class='float-playlist' id='pl-sidebar-container'>
    <div class='pl-btn'>
      
      <p>Queue <em class='count'></em></p>
          <button class='btn btn-danger btn-rounded' id='pl-cear'>Clear</button>
          <button class='btn btn-mint btn-rounded' id='pl-save' style='display:none'>Save</button>
    </div>
    <div class='transparent_img' id='onPlaylist' style=''></div>
        <div class='playlist'>
          <div class='scrollbar'>
            <div class='handle'>
              <div class='mousearea'></div>
            </div>
          </div>
          <div class='frame smart' id='playlist'>
            <ol class="items">
            
            </ol>
          </div>
          <div class='clear'></div>
        </div>        
    </div>
  <!--end play-list sidebar-->