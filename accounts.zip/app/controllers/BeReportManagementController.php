<?php

class BeReportManagementController extends BaseController {

}
