<?php
// This is the EN one.
return array(
	'User_Login' => 'User Login',
	'Login_By_Name_Email_Phone' => 'You can login by name / email / phone number',
	'Username' => 'Username',
	'Password' => 'Password',
	'Login' => 'Login',
	'Register' => 'Register',
	'by_name_email_phone_number' => 'by name / email / phone number',
	'Your_Password' => 'Your Password',
	'Your_used_with_other' => 'Your have already login with another application!, please change your password to login again',
);
