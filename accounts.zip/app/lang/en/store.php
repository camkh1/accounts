<?php
// This is the EN one.
return array(
	'no_product' => 'No product to display', 
	'visitor' => 'Visitor counter', 
	'visitorToday' => 'Today', 
	'visitorYesterday' => 'Yesterday', 
	'visitorLastWeek' => 'Last week', 
	'visitorLastMounth' => 'Last mounth', 
		
	'memeberSince' => 'Member Since', 
	'memeberStatus' => 'Memeber status', 
	'memeberCompanyName' => 'Company', 
	'memeberContactPerson' => 'Contact person', 
	'Tel' => 'Tel', 
	'Email' => 'Email',
	'Webpage' => 'Webpage',
	'fbLike' => 'Facebook  Page',
);
