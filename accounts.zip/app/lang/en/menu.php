<?php
// This is the EN one.
return array(
    'home' => 'Home Page',
    'about' => 'About Me'
);
