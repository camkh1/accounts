<?php
// This is the KH one.
return array(
	'category' => 'Category',
	'all_categories_type' => 'គ្រប់ប្រភេទទាំងអស់',
	'notification' => 'ការ​ជូន​ដំណឹង​',
	'product_title' => 'Product Title',
	'transfer_as' => 'Transfer As',
	'condiction' => 'Condition',
	'price' => 'Price',
	'status' => 'Status',
	'description' => 'Description',
	'publish' => 'Publish',
	'post_date' => 'Post Date',
	'upload_file' => 'Images limit : 10,Image size samller : 2800 width , Image Type : JPG,JPED and PNG',
	'upload_quotation' => 'Upload Quotation',
	'mdd_more_files' => 'Add More Files',
	'contact_name' => 'Your Name',
	'Email' => 'Email',
	'HP' => 'HP',
	'location' => 'ទឺតាំងទាំងអស់',
	'search' => 'ស្មែងរក',
	'search_here' => 'អ្វីដែល​អ្នក​កុពុង​ស្វែងរកទីនេះ',
	'product' => 'ផលិតផល',
	'buyer' => 'អ្នក​ទឹញ',
	'supplier' => 'អ្នក​ផ្គត់​ផ្គង់',
	'save_product_ads' => 'Save Product Ads',
	'point_to_view' => 'Point to View',
	'date_post' => 'Post Date',


    /*======Client Location====*/
    'summary_in_each_location' => 'សង្ខេបប្រចាំទីកន្លែង',
    'summary_in_seller_type' => 'សង្ខេបប្រចាំប្រភេទអ្នកលក់',
    'summary_in_business_site' => 'សង្ខេប​ប្រចាំទំព័រជំនួញ'
);
