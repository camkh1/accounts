<?php
// This is the KM one.
return array(
    'add_new_product' => 'Add New Products',
    'product_management' => 'Product Management',
    'enterprise_tool' => 'Enterprise Tool',
    'setting' => 'Settng',
    'view_profile_info' => 'View Profile info',
    'view_your_site' => 'View your site',
    'your_status' => 'Your Status',
    'chage_password' => 'Chage Password',
    'log_out' => 'Log out',
    'contact_us' => 'Contact Us',
    'about_us' => 'About Us',
    'user_agreement' => 'User Agreement',
    'free_register' => 'Free Register',
    'free_register' => 'Free Register'
);