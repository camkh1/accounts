<?php
// This is the EN one.
return array(
	'no_product' => 'គ្មានផលិតផលដាក់លក់ទេ', 
	'visitor' => 'ចំនួនអ្នកចូលទស្សនា', 
	'visitorToday' => 'ថ្ថៃនេះ', 
	'visitorYesterday' => 'ម្សិលមិញ', 
	'visitorLastWeek' => '១សប្តាហ៍មុន', 
	'visitorLastMounth' => '១ខែមុន', 
		
	'memeberSince' => 'សមាជិកតាំងពីរ', 
	'memeberStatus' => 'ស្ថានភាពសមាជិក', 
	'memeberCompanyName' => 'ក្រុមហ៊ុន', 
	'memeberContactPerson' => 'ទំនាក់ទនង', 
	'Tel' => 'ទូសព្ទ', 
	'Email' => 'ម៉ែល',
	'Webpage' => 'គេហទំព័រ',
	'fbLike' => 'ទំព័រ Facebook ',
);
