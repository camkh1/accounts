<?php
// This is the KM one.
return array(
	'User_Login' => 'ចូល',
	'Login_By_Name_Email_Phone' => 'Login by name / email / phone number',
	'Password' => 'Password',
	'Login' => 'ចូល',
	'Register' => 'ចុះឈ្មោះ',
	'by_name_email_phone_number' => 'by name / email / phone number',
	'Your_Password' => 'Your Password',

);