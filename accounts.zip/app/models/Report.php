<?php

class Report extends Eloquent{

}
