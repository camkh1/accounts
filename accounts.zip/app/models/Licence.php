<?php
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;

class Licence extends Eloquent {

    protected $table = "licence";

    public $timestamps = false;  
}
